import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { type ProductWithCategory } from "@shared/schema";

interface ProductCardProps {
  product: ProductWithCategory;
  whatsappNumber: string;
}

export default function ProductCard({ product, whatsappNumber }: ProductCardProps) {
  const handleWhatsAppOrder = () => {
    const message = `Hi! I'm interested in the ${product.name} (${product.category.name}) - ₦${product.price}`;
    const whatsappUrl = `https://wa.me/${whatsappNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <Card className="product-card bg-card rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300" data-testid={`product-card-${product.id}`}>
      <div className="relative">
        {product.image_path ? (
          <img 
            src={product.image_path} 
            alt={product.name}
            className="w-full h-80 object-cover" 
            data-testid={`product-image-${product.id}`}
          />
        ) : (
          <div className="w-full h-80 bg-muted flex items-center justify-center">
            <i className="fas fa-image text-muted-foreground text-4xl"></i>
          </div>
        )}
        {!product.in_stock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Badge variant="secondary" className="text-white bg-red-600">
              Out of Stock
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-2" data-testid={`product-name-${product.id}`}>
          {product.name}
        </h3>
        {product.description && (
          <p className="text-muted-foreground mb-3" data-testid={`product-description-${product.id}`}>
            {product.description}
          </p>
        )}
        
        <div className="flex justify-between items-center mb-4">
          <span className="text-2xl font-bold text-primary" data-testid={`product-price-${product.id}`}>
            ₦{parseFloat(product.price).toLocaleString()}
          </span>
          <Badge variant="secondary" data-testid={`product-category-${product.id}`}>
            {product.category.name}
          </Badge>
        </div>
        
        <Button
          onClick={handleWhatsAppOrder}
          disabled={!product.in_stock}
          className="w-full bg-green-600 text-white hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          data-testid={`order-button-${product.id}`}
        >
          <i className="fab fa-whatsapp mr-2"></i> 
          {product.in_stock ? 'Order via WhatsApp' : 'Out of Stock'}
        </Button>
      </CardContent>
    </Card>
  );
}
