import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { type Category, type ProductWithCategory } from "@shared/schema";

interface ProductFormProps {
  product?: ProductWithCategory;
  onSubmit: () => void;
  onCancel: () => void;
}

export default function ProductForm({ product, onSubmit, onCancel }: ProductFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category_id: "",
    in_stock: true,
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const { toast } = useToast();

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name || "",
        description: product.description || "",
        price: product.price || "",
        category_id: product.category_id || "",
        in_stock: product.in_stock !== false,
      });
    }
  }, [product]);

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/admin/products", {
        method: "POST",
        headers: {
          'Authorization': 'Bearer admin-token',
        },
        body: data,
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product created successfully",
      });
      onSubmit();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create product",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch(`/api/admin/products/${product?.id}`, {
        method: "PUT",
        headers: {
          'Authorization': 'Bearer admin-token',
        },
        body: data,
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Product updated successfully",
      });
      onSubmit();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update product",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const data = new FormData();
    data.append('name', formData.name);
    data.append('description', formData.description);
    data.append('price', formData.price);
    data.append('category_id', formData.category_id);
    data.append('in_stock', formData.in_stock.toString());
    
    if (imageFile) {
      data.append('image', imageFile);
    }

    if (product) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleInputChange = (field: keyof typeof formData) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData(prev => ({
      ...prev,
      [field]: e.target.value
    }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleCategoryChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      category_id: value
    }));
  };

  const handleStockChange = (checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      in_stock: checked
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Product Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={handleInputChange('name')}
          placeholder="Enter product name"
          required
          data-testid="input-product-name"
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={handleInputChange('description')}
          placeholder="Enter product description"
          rows={3}
          data-testid="input-product-description"
        />
      </div>

      <div>
        <Label htmlFor="price">Price (₦)</Label>
        <Input
          id="price"
          type="number"
          step="0.01"
          value={formData.price}
          onChange={handleInputChange('price')}
          placeholder="Enter price"
          required
          data-testid="input-product-price"
        />
      </div>

      <div>
        <Label htmlFor="category">Category</Label>
        <Select value={formData.category_id} onValueChange={handleCategoryChange}>
          <SelectTrigger data-testid="select-product-category">
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="image">Product Image</Label>
        <Input
          id="image"
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          data-testid="input-product-image"
        />
        {product?.image_path && (
          <div className="mt-2">
            <img 
              src={product.image_path} 
              alt="Current product image" 
              className="w-20 h-20 object-cover rounded"
            />
          </div>
        )}
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="in-stock"
          checked={formData.in_stock}
          onCheckedChange={handleStockChange}
          data-testid="switch-product-stock"
        />
        <Label htmlFor="in-stock">In Stock</Label>
      </div>

      <div className="flex gap-4 pt-4">
        <Button
          type="submit"
          disabled={createMutation.isPending || updateMutation.isPending}
          className="flex-1"
          data-testid="button-submit-product"
        >
          {createMutation.isPending || updateMutation.isPending
            ? "Saving..."
            : product
            ? "Update Product"
            : "Create Product"}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="flex-1"
          data-testid="button-cancel-product"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}
