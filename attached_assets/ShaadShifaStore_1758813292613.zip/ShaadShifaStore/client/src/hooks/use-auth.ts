import { useState, useEffect } from "react";

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('admin-token');
    setIsAuthenticated(token === 'admin-token');
    setIsLoading(false);
  }, []);

  const login = (token: string) => {
    localStorage.setItem('admin-token', token);
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem('admin-token');
    setIsAuthenticated(false);
  };

  return {
    isAuthenticated,
    isLoading,
    login,
    logout,
  };
}
