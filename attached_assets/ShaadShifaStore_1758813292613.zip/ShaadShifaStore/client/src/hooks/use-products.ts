import { useQuery } from "@tanstack/react-query";

export function useProducts(category?: string) {
  return useQuery({
    queryKey: ["/api/products", category ? `?category=${category}` : ""],
  });
}

export function useProduct(id: string) {
  return useQuery({
    queryKey: ["/api/products", id],
    enabled: !!id,
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ["/api/categories"],
  });
}
