import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/Navigation";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { type Category, type ProductWithCategory } from "@shared/schema";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: products = [], isLoading: productsLoading } = useQuery<ProductWithCategory[]>({
    queryKey: ["/api/products", selectedCategory !== "all" ? `?category=${selectedCategory}` : ""],
  });

  const handleCategoryFilter = (category: string) => {
    setSelectedCategory(category);
  };

  const whatsappNumber = "+2348147485879";
  const instagramUrl = "https://www.instagram.com/indian_clothes_in_lagos/";
  const facebookUrl = "https://www.facebook.com/profile.php?id=61579739514388";

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20 pattern-overlay">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6">
              Traditional Kurta Pajama & <br />
              <span className="text-primary">Nigerian Clothing Collection</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Discover our exquisite collection of handcrafted kurta pajamas, blending traditional 
              Indian & Nigerian elegance with contemporary comfort.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
                data-testid="button-shop-collection"
              >
                Shop Collection
              </Button>
              <Button 
                size="lg" 
                className="bg-green-600 text-white hover:bg-green-700"
                asChild
                data-testid="button-whatsapp-order"
              >
                <a 
                  href={`https://wa.me/${whatsappNumber.replace('+', '')}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <i className="fab fa-whatsapp"></i> Order via WhatsApp
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Category Filters */}
      <section className="py-12 bg-card" id="products">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-foreground mb-4">Shop by Fabric</h2>
            <p className="text-muted-foreground">Choose from our premium fabric collections</p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Button
              onClick={() => handleCategoryFilter('all')}
              variant={selectedCategory === 'all' ? 'default' : 'secondary'}
              className="rounded-full"
              data-testid="filter-all"
            >
              All Products
            </Button>
            {categoriesLoading ? (
              <>
                <Skeleton className="h-10 w-20 rounded-full" />
                <Skeleton className="h-10 w-20 rounded-full" />
                <Skeleton className="h-10 w-20 rounded-full" />
              </>
            ) : (
              categories.map((category) => (
                <Button
                  key={category.id}
                  onClick={() => handleCategoryFilter(category.id)}
                  variant={selectedCategory === category.id ? 'default' : 'secondary'}
                  className="rounded-full"
                  data-testid={`filter-${category.name.toLowerCase()}`}
                >
                  {category.name}
                </Button>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {productsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="bg-card rounded-lg shadow-lg overflow-hidden">
                  <Skeleton className="w-full h-80" />
                  <div className="p-6 space-y-4">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <div className="flex justify-between items-center">
                      <Skeleton className="h-8 w-20" />
                      <Skeleton className="h-6 w-16" />
                    </div>
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-16">
              <h3 className="text-2xl font-semibold text-foreground mb-4">No products found</h3>
              <p className="text-muted-foreground">
                {selectedCategory === 'all' 
                  ? 'No products are currently available.' 
                  : 'No products found in this category.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {products.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  whatsappNumber={whatsappNumber}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-8">Get in Touch</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Connect with us through WhatsApp for instant orders or follow us on social media
          </p>
          <div className="flex flex-wrap justify-center gap-6">
            <Button 
              size="lg" 
              className="bg-green-600 text-white hover:bg-green-700"
              asChild
              data-testid="contact-whatsapp"
            >
              <a 
                href={`https://wa.me/${whatsappNumber.replace('+', '')}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3"
              >
                <i className="fab fa-whatsapp text-xl"></i>
                <span>{whatsappNumber}</span>
              </a>
            </Button>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
              asChild
              data-testid="contact-instagram"
            >
              <a 
                href={instagramUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3"
              >
                <i className="fab fa-instagram text-xl"></i>
                <span>@indian_clothes_in_lagos</span>
              </a>
            </Button>
            <Button 
              size="lg" 
              className="bg-blue-600 text-white hover:bg-blue-700"
              asChild
              data-testid="contact-facebook"
            >
              <a 
                href={facebookUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-3"
              >
                <i className="fab fa-facebook text-xl"></i>
                <span>Facebook Page</span>
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Floating WhatsApp Button */}
      <a 
        href={`https://wa.me/${whatsappNumber.replace('+', '')}`} 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-600 text-white p-4 rounded-full shadow-lg hover:bg-green-700 transition-colors z-50 animate-pulse"
        data-testid="floating-whatsapp"
      >
        <i className="fab fa-whatsapp text-2xl"></i>
      </a>
    </div>
  );
}
