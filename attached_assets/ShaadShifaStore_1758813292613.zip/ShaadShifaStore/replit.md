# Overview

This is a full-stack e-commerce application for traditional clothing (kurta pajamas and Nigerian clothing) called "SHAAD-n-SHIFA". The application features a public-facing storefront where customers can browse products by category and place orders via WhatsApp, plus an admin panel for managing products, categories, and orders. The system is built with a React frontend, Express.js backend, and uses PostgreSQL with Drizzle ORM for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight alternative to React Router)
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom color scheme and theming support
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation via @hookform/resolvers

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **File Uploads**: Multer middleware for handling product image uploads
- **Session Management**: Simple token-based authentication (admin-only)
- **API Design**: RESTful endpoints with separate public and admin routes

## Database Schema
- **Users**: Admin authentication with username/password
- **Categories**: Product categorization (Cotton, Linen, Silk)
- **Products**: Product catalog with images, pricing, and stock status
- **Orders**: Customer orders with WhatsApp integration for order processing

## Authentication & Authorization
- **Admin Authentication**: Simple credential-based login (username: "admin", password: "saad@789")
- **Session Management**: Local storage token persistence
- **Route Protection**: Middleware-based authorization for admin endpoints

## File Storage
- **Product Images**: Local file system storage in `/uploads` directory
- **Image Processing**: Basic file type validation and size limits (5MB max)
- **Serving**: Static file serving via Express for uploaded images

## Development & Build
- **Development Server**: Vite dev server with HMR and proxy to Express backend
- **Production Build**: Vite builds frontend to `dist/public`, esbuild bundles backend
- **Database Management**: Drizzle Kit for schema migrations and database initialization
- **Environment**: ES modules throughout with TypeScript compilation

# External Dependencies

## Database & ORM
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **drizzle-orm**: Type-safe ORM with PostgreSQL adapter
- **drizzle-kit**: Database schema management and migrations
- **connect-pg-simple**: PostgreSQL session store (configured but not actively used)

## UI & Styling
- **@radix-ui/***: Comprehensive set of headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Utility for creating variant-based component APIs
- **lucide-react**: Icon library for React

## Form & Validation
- **react-hook-form**: Performant forms with minimal re-renders
- **@hookform/resolvers**: Resolver library for validation schema integration
- **zod**: TypeScript-first schema validation
- **drizzle-zod**: Integration between Drizzle schemas and Zod validation

## Development Tools
- **@replit/vite-plugin-***: Replit-specific development plugins for error handling and debugging
- **tsx**: TypeScript execution engine for development
- **esbuild**: Fast JavaScript bundler for production builds

## Communication
- **WhatsApp Business API**: Customer order processing via WhatsApp links (no direct API integration, uses wa.me links)

## File Handling
- **multer**: Node.js middleware for handling multipart/form-data (image uploads)
- **@types/multer**: TypeScript definitions for Multer