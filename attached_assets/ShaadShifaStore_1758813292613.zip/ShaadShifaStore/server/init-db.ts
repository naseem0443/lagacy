import { db } from "./db";
import { categories, users } from "@shared/schema";
import { eq } from "drizzle-orm";

async function initializeDatabase() {
  console.log("Initializing database...");
  
  try {
    // Check if categories already exist
    const existingCategories = await db.select().from(categories);
    
    if (existingCategories.length === 0) {
      console.log("Creating default categories...");
      
      // Create the three required categories
      await db.insert(categories).values([
        {
          name: "Cotton",
          description: "Premium cotton kurta pajamas and traditional wear"
        },
        {
          name: "Linen", 
          description: "Breathable linen clothing for comfort and style"
        },
        {
          name: "Silk",
          description: "Luxurious silk garments for special occasions"
        }
      ]);
      
      console.log("Categories created successfully!");
    } else {
      console.log("Categories already exist, skipping creation.");
    }
    
    // Check if admin user exists
    const adminUser = await db.select().from(users).where(eq(users.username, "admin"));
    
    if (adminUser.length === 0) {
      console.log("Creating admin user...");
      
      await db.insert(users).values({
        username: "admin",
        password: "saad@789" // In production, this should be hashed
      });
      
      console.log("Admin user created successfully!");
    } else {
      console.log("Admin user already exists, skipping creation.");
    }
    
    console.log("Database initialization completed!");
    
  } catch (error) {
    console.error("Error initializing database:", error);
    process.exit(1);
  }
}

// Only run if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  initializeDatabase()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error(error);
      process.exit(1);
    });
}

export { initializeDatabase };
