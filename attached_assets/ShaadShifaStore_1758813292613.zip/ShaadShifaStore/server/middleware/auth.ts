import type { Request, Response, NextFunction } from "express";
import { storage } from "../storage";

export interface AuthenticatedRequest extends Request {
  user?: { id: string; username: string };
}

export async function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(401).json({ message: "Username and password required" });
  }

  // Simple authentication for admin user
  if (username === "admin" && password === "saad@789") {
    req.user = { id: "admin", username: "admin" };
    return next();
  }

  return res.status(401).json({ message: "Invalid credentials" });
}

export function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  // For demonstration, we'll use a simple session check
  // In production, you'd use proper JWT tokens or sessions
  const authHeader = req.headers.authorization;
  
  if (authHeader === "Bearer admin-token") {
    req.user = { id: "admin", username: "admin" };
    return next();
  }
  
  return res.status(401).json({ message: "Unauthorized" });
}
