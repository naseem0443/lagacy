import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { requireAuth, authMiddleware } from "./middleware/auth";
import { upload } from "./middleware/upload";
import { insertCategorySchema, insertProductSchema, insertOrderSchema, loginSchema } from "@shared/schema";
import express from "express";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Serve uploaded images
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // Public routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/products", async (req, res) => {
    try {
      const { category } = req.query;
      let products;
      
      if (category && category !== 'all') {
        products = await storage.getProductsByCategory(category as string);
      } else {
        products = await storage.getProducts();
      }
      
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Authentication
  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      if (loginData.username === "admin" && loginData.password === "saad@789") {
        res.json({ 
          success: true, 
          token: "admin-token",
          user: { id: "admin", username: "admin" }
        });
      } else {
        res.status(401).json({ message: "Invalid credentials" });
      }
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Order creation (public endpoint for WhatsApp orders)
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      
      // Generate WhatsApp link with product details
      const product = await storage.getProduct(orderData.product_id);
      if (product) {
        const whatsappMessage = `Hi! I would like to order: ${product.name} (${product.category.name}) - ₦${product.price}. Customer: ${orderData.customer_name}, Phone: ${orderData.customer_phone}`;
        const whatsappLink = `https://wa.me/2348147485879?text=${encodeURIComponent(whatsappMessage)}`;
        
        res.json({ 
          order, 
          whatsappLink,
          message: "Order created successfully. Please complete your order via WhatsApp." 
        });
      } else {
        res.json({ order, message: "Order created successfully." });
      }
    } catch (error) {
      res.status(400).json({ message: "Failed to create order" });
    }
  });

  // Protected admin routes
  app.get("/api/admin/orders", authMiddleware, async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.post("/api/admin/categories", authMiddleware, async (req, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.json(category);
    } catch (error) {
      res.status(400).json({ message: "Failed to create category" });
    }
  });

  app.post("/api/admin/products", authMiddleware, upload.single('image'), async (req, res) => {
    try {
      const productData = insertProductSchema.parse({
        ...req.body,
        price: req.body.price,
        in_stock: req.body.in_stock === 'true'
      });
      
      if (req.file) {
        productData.image_path = `/uploads/${req.file.filename}`;
      }
      
      const product = await storage.createProduct(productData);
      res.json(product);
    } catch (error) {
      res.status(400).json({ message: "Failed to create product", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/admin/products/:id", authMiddleware, upload.single('image'), async (req, res) => {
    try {
      const updateData: any = { ...req.body };
      
      if (req.body.price) {
        updateData.price = req.body.price;
      }
      
      if (req.body.in_stock !== undefined) {
        updateData.in_stock = req.body.in_stock === 'true';
      }
      
      if (req.file) {
        updateData.image_path = `/uploads/${req.file.filename}`;
      }
      
      const product = await storage.updateProduct(req.params.id, updateData);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(400).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/admin/products/:id", authMiddleware, async (req, res) => {
    try {
      const success = await storage.deleteProduct(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  app.put("/api/admin/orders/:id", authMiddleware, async (req, res) => {
    try {
      const { status } = req.body;
      const order = await storage.updateOrderStatus(req.params.id, status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // Admin stats endpoint
  app.get("/api/admin/stats", authMiddleware, async (req, res) => {
    try {
      const products = await storage.getProducts();
      const orders = await storage.getOrders();
      
      const stats = {
        totalProducts: products.length,
        pendingOrders: orders.filter(o => o.status === 'pending').length,
        whatsappOrders: orders.length,
        revenue: orders.reduce((sum, order) => sum + parseFloat(order.product.price), 0)
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
